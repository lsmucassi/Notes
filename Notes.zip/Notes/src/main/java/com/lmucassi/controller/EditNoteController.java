package com.lmucassi.controller;

import com.lmucassi.model.Note;
import com.lmucassi.NoteRepository;
import com.lmucassi.view.NoteForm;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 * @author <a href="mailto:mlassiter@lassitercg.com">Mark Lassiter</a>
 */
@RequestScoped
@Named
public class EditNoteController {

	@Inject
	NoteForm noteForm;

	@Inject
	NoteRepository noteRepository;

	public void save() {
		noteRepository.merge(noteForm.getNote());
	}

	public void preRenderViewEvent() {
		if (noteForm.getNote() == null) {
			initializeNote();
		}
	}

	private void initializeNote() {
		if (noteForm.getNoteId() == null) {
			noteForm.setNote(new Note());
			return;
		}
		Note note = noteRepository.find(noteForm.getNoteId());
		noteForm.setNote(note);
	}
}