package com.lmucassi.controller;

import com.lmucassi.model.DBConnection;
import com.lmucassi.model.Note;
import com.lmucassi.NoteRepository;
import com.lmucassi.view.SearchForm;
import org.omnifaces.cdi.ViewScoped;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@ViewScoped
@Named
public class NoteDatatable implements Serializable {

	@Inject
	NoteRepository noteRepository;
	DBConnection dbConnection ;

	@Inject
	SearchForm searchForm;

	private List<Note> values;

	public List<Note> getValues() {
		if (values == null)
			refresh();
		return values;
	}

	public void refresh() {
		if (searchForm.getEventDate() == null) {
			values = noteRepository.queryAll();
//			values = dbConnection.readDB();
		} else {
			values = noteRepository.queryEventDate(searchForm.getEventDate());
		}
	}
}