package com.lmucassi.controller;

import com.lmucassi.model.Note;
import com.lmucassi.NoteRepository;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;

@RequestScoped
@Named
public class NoteController implements Serializable {

	@Inject
	NoteRepository noteRepository;

	@Inject
	NoteDatatable noteDatatable;

	public void remove(Note note) {
		noteRepository.remove(note);
		noteDatatable.refresh();
		FacesContext.getCurrentInstance()
				.addMessage(null, new FacesMessage("Successfully deleted note " + note.getNoteNum()));
	}

}