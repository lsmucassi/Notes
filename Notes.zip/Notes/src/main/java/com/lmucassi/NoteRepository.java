package com.lmucassi;

import com.lmucassi.model.DBConnection;
import com.lmucassi.model.Note;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Repository for the {@link Note} entity.
 */
@Stateless
public class NoteRepository {

    @PersistenceContext(unitName = "NotesPU")
    EntityManager entityManager;
    DBConnection dbConnection;

    static List<Note> data = new ArrayList<>();

    public List<Note> queryAll() {
        TypedQuery<Note> query = entityManager.createQuery("select e from Note e", Note.class);
        return query.getResultList();
    }

    public List<Note> queryEventDate(Date eventDate) {
        TypedQuery<Note> query = entityManager
                .createQuery("select e from Note e where e.eventDate >= :eventDate", Note.class);
        query.setParameter("eventDate", eventDate);
        return query.getResultList();
    }

    public Note find(Integer id) {
        return entityManager.find(Note.class, id);
    }

    public Note merge(Note note) {
        if (note != null)
            return entityManager.merge(note);
        return null;
    }

    public void persist(Note note) {
        entityManager.persist(note);
    }

    public void remove(Note note) {
        Note attached = find(note.getNoteNum());
        entityManager.remove(attached);
//        dbConnection.delDB(note);

    }
}