package com.lmucassi.model;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * The employee JPA entity.
 */
@Entity
@Table(name = "notes_table", schema = "notes_schema", catalog = "notes")
public class Note implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "note_no", updatable = false, nullable = false)
	private Integer noteNum;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "note_uuid")
	private Integer noteUUId;

	@Column(name = "first_name", length = 50)
	private String firstName;

	@Column(name = "last_name", length = 50)
	private String lastName;

	@Column(name = "category", length = 50)
	private String category;

	@Column(name = "title", length = 50)
	private String title;

	@Column(name = "descr", length = 50)
	private String description;

	@Column(name = "location", length = 50)
	private String location;

	@Column(name = "event_date")
	@Temporal(TemporalType.DATE)
	private Date eventDate;

	@CreationTimestamp
	@Column(name = "created_date")
	@Temporal(TemporalType.DATE)
	private Date createdDate = new Date();

	public Integer getNoteNum() {
		return noteNum;
	}
	public void setNoteNum(final Integer noteNo) {
		this.noteNum = noteNo;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}
	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	public String getCategory() {
		return category;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	public String getLocation() {
		return location;
	}

	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(final Date eventDate) {
		this.eventDate = eventDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(final Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setNoteUUId(UUID note_id) {
		this.noteUUId = noteUUId;
	}
	public Integer getNoteUUId() {
		return noteUUId;
	}
}