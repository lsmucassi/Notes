package com.lmucassi.model;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DBConnection {
    static List<Note> data = new ArrayList<>();
    private static String url = "jdbc:postgresql://localhost/notes?user=postgres&password=Magobeni5956@";
    private static String readSql = "SELECT note_num, first_name, last_name, category, title, descr, location, " +
            "event_date, date_made FROM notes_schema.notes_table";
    private static String updateSql = "UPDATE notes_schema.notes_table SET last_name = ? WHERE note_num = ?";
    private static String insertSql = "INSERT INTO notes_schema.notes_table( note_num, first_name, last_name, " +
            "category, title, descr, location, event_date, date_made) VALUES ( ?,?, ?, ?, ?, ?, ?, ?, ?)";

    public static void main(String[] args) {
//        upDateDB();
      /*  readDBContentnt();
        String url = "jdbc:postgresql://localhost/test";
        Properties props = new Properties();
        props.setProperty("user","F5102421");
        props.setProperty("password","Magobeni5956@");
        props.setProperty("ssl","true");
        Connection conn = DriverManager.getConnection(url, props);
        readDBContent();*//*

        String startDate1 = "2042-03-12 10:42:42";
        String eventDate1 = "2042-05-03 10:42:42";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss");
        DateTimeFormatter eformatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss");
        LocalDate sdate = LocalDate.parse(startDate1, formatter);
        LocalDate edate = LocalDate.parse(eventDate1, eformatter);
        java.sql.Date sqlDateS = java.sql.Date.valueOf(sdate);
        Date sqlDateE = Date.valueOf(edate);

        insertDBContent(10007,"oldmlee", "oldmuc", "olddate", "go dude", "just do it my guy", "somewhere", sqlDateE, sqlDateS); */
    }

    public DBConnection() {}

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(url);
    }

    public static List<Note> readDB() {
        try (Connection com = connect();
             Statement dataStmt = com.createStatement()){
                ResultSet rs;
                rs = dataStmt.executeQuery(readSql);

            while (rs.next()) {
                Note note = new Note();
                note.setNoteNum((Integer) rs.getObject( "note_num" ));
                note.setFirstName( rs.getString("first_name"));
                note.setLastName(rs.getString("last_name"));
                note.setCategory(rs.getString("category"));
                note.setTitle(rs.getString("title"));
                note.setDescription(rs.getString("descr"));
                note.setLocation(rs.getString("location"));
                note.setEventDate(rs.getDate("event_date"));
                note.setCreatedDate(rs.getDate("date_made"));
                data.add(note);
            }
        } catch (Exception e) {
            System.err.println("ExceptionErr: [Read From DB ]\n" + e + "\n" + e.getMessage());
        }
        return data;
    }

    public static void insertDB(int num, String name, String last_name, String category, String title, String decr,
                                       String location, Date eventDate, Date sqlDate) {
        try (Connection com = connect();
            PreparedStatement statement = com.prepareStatement(insertSql)) {

                statement.setInt(1, num);
                statement.setString(2, name);
                statement.setString(3, last_name);
                statement.setString(4, category);
                statement.setString(5, title);
                statement.setString(6, decr);
                statement.setString(7, location);
                statement.setDate(8, Date.valueOf(String.valueOf(eventDate)));
                statement.setDate(9, Date.valueOf(String.valueOf(sqlDate)));

                int inserted = statement.executeUpdate();
                if (inserted > 0) {
                    System.out.println("A new user was inserted successfully!");
                }
        } catch (Exception e) {
            System.out.println("ExceptionErr: [ WRITE TO DB ] " + e + "\n" + e.getMessage());
            System.out.println("DriverError: Driver Not Found \nOn [ INSERT TO DB ] - " + e + " - " + e.getMessage());
        }
    }

    public static int updateDB() {
        //search for not with ID
        //if note is found, update note
        //Rerender updates

        int affectedrows = 0;

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(updateSql)) {
                pstmt.setString(1, "");
                pstmt.setInt(2, 10007);
                affectedrows = pstmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("ExceptionError: [ UPDATE DB ]\n" + ex.getMessage());
        }
        return affectedrows;
    }

    public void delDB(Note note) {
        String delSql = "DELETE FROM notes_schema.notes_table WHERE note_num = ?";
//        int affectedRows = 0;

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(delSql)) {
                pstmt.setInt(1, note.getNoteNum());
//                affectedRows = pstmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
//        return affectedRows;
    }
}
