package com.lmucassi.view;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.Date;

@SessionScoped
@Named
public class SearchForm implements Serializable {

	private Date eventDate;

	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(final Date eventDate) {
		this.eventDate = eventDate;
	}
}