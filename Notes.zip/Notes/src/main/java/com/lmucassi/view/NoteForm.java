package com.lmucassi.view;

import com.lmucassi.model.Note;
import org.omnifaces.cdi.ViewScoped;

import javax.inject.Named;
import java.io.Serializable;

@ViewScoped
@Named
public class NoteForm implements Serializable {

	private Integer noteId;

	private Note note;

	public Integer getNoteId() {
		return noteId;
	}

	public void setNoteId(final Integer noteId) {
		this.noteId = noteId;
	}

	public Note getNote() {
		return note;
	}

	public void setNote(final Note note) {
		this.note = note;
	}
}