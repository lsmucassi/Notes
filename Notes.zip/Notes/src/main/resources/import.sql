INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10001, '1953-09-02', 'Georgi', 'Facello', '1986-06-26', 'reminder', 'Leave Early', 'Leave early tomorrow', 'not applicable');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10002, '1964-06-02', 'Bezalel', 'Simmel', '1985-11-21', 'minutes', 'Board Meeting', 'Schedule follow up meeting', 'Board room 130B');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10003, '1959-12-03', 'Parto', 'Bamford', '1986-08-28', 'Study', 'Learn Xml', 'Find xml tutorials on the net', 'Study Labs');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10004, '1954-05-01', 'Chirstian', 'Koblick', '1986-12-01', 'Holiday', 'valentines', 'Get a valentines gift', 'The Foodies Space');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10005, '1955-01-21', 'Kyoichi', 'Maliniak', '1989-09-12', 'Travel', 'Go to Egypt', 'Visit the pyramids', 'Egypt');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10006, '1953-04-20', 'Anneke', 'Preusig', '1989-06-02', 'Meditation', 'Yoga', 'Meditation session with my personal trainer', 'Home');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10007, '1957-05-23', 'Tzvetan', 'Zielinski', '1989-02-10', 'Reminder', 'Meeting', 'Sponsorship meeting', 'Sponsors Location');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10008, '1958-02-19', 'Saniya', 'Kalloufi', '1994-09-15', 'Event', 'Birthday', 'Go to Parto Bamfords birth day party', '32 Walking Road');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10009, '1952-04-19', 'Sumant', 'Peac', '1985-02-18', 'Reminder', 'Pick Up Kids', 'Pick up kids from school', 'Greensward High School');
INSERT INTO note (note_no, event_date, first_name, last_name, created_date, category, title, descr, location)
  VALUES (10010, '1963-06-01', 'Duangkaew', 'Piveteau', '1989-08-24', 'Reminder', 'Presentation', 'Prepare a presentation', 'Home');
