This project is made public for use in training.  The source code is not production
quality and is only meant to demonstrate some basic Java EE concepts.

The video can be found [here](https://youtu.be/Qt-JiyrRH2g).  The text seen in the video can be found on the [JavaEE Introduction](javaee-intro.md) page.
